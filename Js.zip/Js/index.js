//Utility Functions
function ElementfromString(string){
let div=document.createElement('div');
div.innerHTML=string;
return div.firstElementChild;
}
//validation in url box
let url=document.getElementById('url');
url.addEventListener('blur',()=>{
    let regex=/^(http)/;
    let str=url.value;
    if(regex.test(str)){
        console.log('done');
        url.classList.add('is-valid');
        url.classList.remove('is-invalid');
    }
    else{
    url.classList.add('is-invalid');
    url.classList.remove('is-valid');
    }
})
// Hide Parameter box
let parmetersBox = document.getElementById("parmetersBox");
parmetersBox.style.display = "none";
let requestJsonBox = document.getElementById("requestJsonBox");
// Whenm User Choose Json Box Hide Param Box if Choose paramBox Hide JSon Box
let jsonRadio = document.getElementById("jsonRadio");
let paramsRadio = document.getElementById("paramsRadio");
//Add Event Listener on Both
jsonRadio.addEventListener("click", () => {
  parmetersBox.style.display = "none";
  requestJsonBox.style.display = "block";
});
paramsRadio.addEventListener("click", () => {
  parmetersBox.style.display = "block";
  requestJsonBox.style.display = "none";
});

//If user Click on + Button Add More Parameter
let addesparamcount=0;
let addParam = document.getElementById("addParam");
addParam.addEventListener("click", () => {
  let params = document.getElementById("params");
 
  let string = `<div class="form-row my-3">
        <label for="url" class="col-sm-2 col-form-label">Parameter ${addesparamcount +2}</label>
        <div class="col-md-4">
        <input
            type="text"
            class="form-control"
            id="parameterKey${addesparamcount +2}"
            placeholder="Enter Parameter Key ${addesparamcount +2}"
        />
        </div>
        <div class="col-md-4">
        <input
            type="text"
            class="form-control"
            id="parameterValue${addesparamcount +2}"
            placeholder="Enter parameter Value ${addesparamcount +2}"
        />
        </div>
        <button class="btn btn-primary deleteparam" > - </button>
    </div>`;
let paramElement=ElementfromString(string);
params.appendChild(paramElement)
//Add an Event Listener to remove the element when clicking on - button
let deleteparam=document.getElementsByClassName('deleteparam');
for(item of deleteparam){
    // TODO :- Add a confirmation Box
    item.addEventListener('click',(e)=>{
        e.target.parentElement.remove();
    })
}
    addesparamcount ++;

});

// When User Click on Submit Button
let submit=document.getElementById('submit');
submit.addEventListener('click',()=>{
// let responseJsonText=document.getElementById('responseJsonText').innerHTML='Please Wait... While we load your Response ..';
document.getElementById('responsePrism').innerHTML='Please Wait... While we load your Response ..';
// Taking Values of input Types
let url=document.getElementById('url').value;
let requestType=document.querySelector("input[name='requestType']:checked").value;
let contentType=document.querySelector("input[name='contentType']:checked").value;


if(contentType=='params'){
    data={};
    for(let i=0;i<addesparamcount+1;i++){
        if(document.getElementById('parameterKey'+(i+1)) != undefined){
        let key=document.getElementById('parameterKey'+(i+1)).value;
        let value=document.getElementById('parameterValue'+(i+1)).value;
        data[key]=value;
        }
    }
    data=JSON.stringify(data);
}
else{
    data=document.getElementById('reuestJsonText').value;
}

console.log(url,requestType,contentType,data)//console.for debugging

//if the request type is get invoke fetch api for get method
if(requestType=='GET'){
    fetch(url,{
        method:'GET',
    })
    .then(response=>response.text())
    .then((text)=>{
       
        document.getElementById('responsePrism').innerHTML=text;
        Prism.highlightAll()  
    });
}
else{
    fetch(url,{
        method:'POST',
        body:data,
        headers:{
            "Content-type":"application/json;charset=UTF-8"
        }
    })
    .then(response=>response.text())
    .then((text)=>{
document.getElementById('responsePrism').innerHTML=text;
Prism.highlightAll()    
});  
}

});